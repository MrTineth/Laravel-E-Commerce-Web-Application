-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2024 at 01:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_project_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Eaque Tempore', 'eaque-tempore', '4.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(2, 'Est Et', 'est-et', '1.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(3, 'Voluptatibus Aut', 'voluptatibus-aut', '3.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(4, 'Est Cumque', 'est-cumque', '3.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(5, 'Illum Qui', 'illum-qui', '6.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(6, 'A Maxime', 'a-maxime', '1.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Quia Perferendis', 'quia-perferendis', '3.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(2, 'Voluptas Eum', 'voluptas-eum', '2.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(3, 'Quibusdam Est', 'quibusdam-est', '4.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(4, 'Aut Sit', 'aut-sit', '5.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(5, 'Incidunt Molestias', 'incidunt-molestias', '2.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(6, 'Sint Illum', 'sint-illum', '6.jpg', '2024-02-06 02:14:57', '2024-02-06 02:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(17, '2014_10_12_000000_create_users_table', 1),
(18, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(19, '2014_10_12_100000_create_password_resets_table', 1),
(20, '2019_08_19_000000_create_failed_jobs_table', 1),
(21, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(22, '2024_02_06_042537_create_brands_table', 1),
(23, '2024_02_06_042559_create_categories_table', 1),
(24, '2024_02_06_042627_create_products_table', 1),
(25, '2024_02_11_045640_create_orders_table', 2),
(26, '2024_02_11_045701_create_order_items_table', 2),
(27, '2024_02_11_045721_create_shippings_table', 2),
(28, '2024_02_11_045758_create_transactions_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(8,2) NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `locality` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `zip` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'home',
  `status` enum('ordered','delivered','canceled') NOT NULL DEFAULT 'ordered',
  `is_shipping_different` tinyint(1) NOT NULL DEFAULT 0,
  `delivered_date` date DEFAULT NULL,
  `canceled_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `options` longtext DEFAULT NULL,
  `rstatus` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `regular_price` decimal(8,2) NOT NULL,
  `sale_price` decimal(8,2) DEFAULT NULL,
  `SKU` varchar(255) NOT NULL,
  `stock_status` enum('instock','outofstock') NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `image` varchar(255) NOT NULL,
  `images` text NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `short_description`, `description`, `regular_price`, `sale_price`, `SKU`, `stock_status`, `featured`, `quantity`, `image`, `images`, `category_id`, `brand_id`, `created_at`, `updated_at`) VALUES
(1, 'Ea Voluptatem', 'ea-voluptatem', 'Provident in perferendis nemo qui commodi eligendi. Ducimus omnis non sed modi. Sint ea provident consequuntur omnis sit iure vel. Sed reprehenderit nisi nostrum beatae rerum corporis eos tenetur.', 'Sit a numquam iste aliquid qui non. Nam aut commodi vitae pariatur. Quia quia nam provident soluta maiores. Explicabo eum nihil fugiat voluptatem doloribus et aut. Qui quo eum mollitia ut distinctio. Nam harum est nam expedita. Et in et enim qui aut autem at. Officia ad voluptatem commodi et eaque. Ipsam omnis possimus odit neque. Iure commodi qui ipsum vitae alias sed tempore. Quos beatae eveniet rem nemo. Ipsa illum magnam aut dolorem quam voluptates est ut. Est omnis nisi at quam illo aut.', 2.00, NULL, 'SMD178', 'instock', 0, 131, '4.jpg', '4.jpg', 3, 1, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(2, 'Quasi Reiciendis', 'quasi-reiciendis', 'Blanditiis veniam tempora temporibus quod delectus libero. Rerum porro ipsa non deleniti similique aut. Eos tempore id et dolorum.', 'Accusamus totam sequi cumque quos aut. Cum est rerum ipsam velit molestiae officiis qui voluptatem. Eos quo dicta quibusdam. At accusantium sed nobis eveniet quo. Odio et nisi consequuntur dolorem. Similique ut laudantium laboriosam. Ut et itaque omnis placeat. Non adipisci quo ad accusamus id ut rem. Excepturi esse explicabo sunt doloribus eius ea neque. Nihil eius sit accusantium alias cum.', 5.00, NULL, 'SMD247', 'instock', 0, 104, '9.jpg', '9.jpg', 2, 1, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(3, 'Beatae Necessitatibus', 'beatae-necessitatibus', 'Sunt totam molestiae ex earum maxime. Omnis natus amet ut quaerat sit et voluptatem doloremque. Dolor ullam non quia minima. Quia sint repudiandae exercitationem nobis.', 'Pariatur earum asperiores reiciendis. Sequi impedit in aut ab aut ratione sit. Ducimus qui dolores dolore ut mollitia molestias quia. Odio cupiditate alias facere sit consequatur eius consequuntur nihil. Vel doloribus facere reiciendis est aperiam eum non. Illo amet quisquam aliquid. Omnis quidem necessitatibus libero et est. Omnis nam quam vitae at in vero et hic. Dolore ab quaerat ex aliquid cumque quae aliquid.', 17.00, NULL, 'SMD313', 'instock', 0, 114, '8.jpg', '8.jpg', 1, 4, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(4, 'Ipsa Sit', 'ipsa-sit', 'Vitae perferendis non doloremque quas quasi omnis. Hic voluptatem ut rerum accusantium voluptas earum. A a rerum et doloremque quia.', 'Iusto eum sed nisi porro aut harum veritatis. Veritatis magnam quasi sed et eum maxime veniam. Nulla nostrum architecto quia delectus dignissimos rerum. Sit dolores tenetur occaecati blanditiis repudiandae aliquid et. Aut enim et odit corporis. Molestiae qui ea est molestiae nulla blanditiis. Et sit molestias adipisci nihil dolores omnis dolor eos. Similique esse quasi magnam praesentium architecto dolor molestiae.', 14.00, NULL, 'SMD214', 'instock', 0, 195, '14.jpg', '14.jpg', 5, 5, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(5, 'Est Officia', 'est-officia', 'Eius iure tenetur molestiae. Porro ipsum dolorum ab aut. Nisi omnis aliquid aliquam repellat ullam molestiae error. Qui sit aspernatur est minus esse porro vero.', 'Quisquam voluptate nostrum asperiores quis. Non itaque ut mollitia optio est porro ducimus qui. At ea officiis labore voluptas eveniet molestias odio. Iure distinctio eum quae molestias voluptatem eos incidunt. Omnis vel error adipisci qui. Earum hic totam placeat delectus qui velit animi nostrum. Velit eaque molestiae optio. Asperiores magni iure est ab aut consequatur aut optio. Sint velit libero soluta necessitatibus. Aspernatur rerum aliquid ea expedita doloremque.', 16.00, NULL, 'SMD426', 'instock', 0, 158, '3.jpg', '3.jpg', 1, 5, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(6, 'Perferendis Maxime', 'perferendis-maxime', 'Ut odio voluptas et velit voluptatem quam. Beatae autem delectus molestias quo eius. Autem corporis molestiae cupiditate consequatur sequi alias.', 'Ab et ipsa dolorem eum quaerat. Repudiandae aut aut explicabo deleniti voluptate laborum. Eum facere id tempora ea fugit. Nostrum voluptatum at est hic aut temporibus qui hic. Quisquam illo doloribus quae itaque aut exercitationem. Cupiditate sapiente debitis magni. Consequatur et molestias sit ea. Et impedit quia qui illo. Quasi odio repellat maiores illum fugit. Est reprehenderit ea aut non commodi.', 1.00, NULL, 'SMD133', 'instock', 0, 166, '7.jpg', '7.jpg', 6, 3, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(7, 'Dolorum Id', 'dolorum-id', 'A totam perspiciatis consequatur iusto repellat dolores. Libero nulla voluptate aperiam adipisci ea dolorem. Tenetur quo sit et.', 'Quibusdam vel est impedit accusamus est quia et. Velit velit inventore sed sed. Aut unde numquam fuga et. Et nostrum debitis qui tempora enim sed. Provident velit quidem praesentium et facere. Ipsa accusantium tempora ut fuga eveniet. Totam ad dolores omnis vitae qui consequatur. Incidunt incidunt velit et deleniti vitae explicabo. Alias est minus quia itaque. Id maiores recusandae repellat maxime ea id sunt. Sed architecto nihil aspernatur quisquam sit consequuntur.', 22.00, NULL, 'SMD280', 'instock', 0, 153, '2.jpg', '2.jpg', 6, 2, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(8, 'Adipisci Quia', 'adipisci-quia', 'Magnam consequatur deleniti nemo vitae. Ipsa aspernatur dolor cumque qui earum minus. Et et veniam dolor amet et sequi. Perferendis et et dolorem voluptas aut et.', 'Libero corrupti itaque in nulla. Aut reprehenderit cum autem. Doloremque illum exercitationem non et architecto quia. Consequatur cumque sint nihil voluptas et nihil. Nulla quos iusto recusandae sed omnis. Exercitationem aut omnis repellat pariatur molestias. Velit sed itaque et earum. Laboriosam et error expedita cupiditate. Provident repudiandae qui minus ducimus molestiae neque. Sed corrupti qui beatae consequatur ratione sed. Temporibus aut rerum ex illum quo facilis.', 16.00, NULL, 'SMD164', 'instock', 0, 114, '22.jpg', '22.jpg', 5, 4, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(9, 'Ipsum Est', 'ipsum-est', 'Ut qui quia nulla a vero dolore. Distinctio molestiae possimus fugiat architecto perferendis voluptas unde quia. Quidem excepturi at provident cupiditate. Ipsam sint et ratione provident voluptatem.', 'Omnis incidunt sunt amet non non. Deserunt totam eum odit suscipit dicta laboriosam non sed. Eaque ea molestiae autem numquam. Neque nihil aut facere nihil. Sunt quos commodi eum aliquid aut sit. Consequatur sit aliquam ad eligendi sed vitae et. Aliquid est sint veritatis vel commodi. Aut reiciendis consequatur blanditiis iure alias est. Ea impedit dolor deserunt autem voluptates. Ut ad et quia iusto quos.', 2.00, NULL, 'SMD400', 'instock', 0, 186, '2.jpg', '2.jpg', 1, 2, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(10, 'Corrupti Rem', 'corrupti-rem', 'Est maxime maxime et ad et ab ipsam laborum. In maxime suscipit porro numquam consequatur consectetur veniam.', 'Sunt qui in harum ab. Repudiandae occaecati ut pariatur. Est saepe earum repudiandae eaque doloremque. Culpa nihil sed aut sunt. Et sed et qui ut. Nihil nihil magni modi. Quidem eligendi in illum eaque. Sunt minus quod laborum quis consequuntur est. Quis commodi quibusdam vero enim ratione illo odio. Sunt illo odit officia autem. Impedit facilis maiores totam dolor nemo libero.', 4.00, NULL, 'SMD418', 'instock', 0, 121, '8.jpg', '8.jpg', 3, 3, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(11, 'Saepe Pariatur', 'saepe-pariatur', 'Voluptatem maiores explicabo porro et. Exercitationem culpa itaque non omnis.', 'Consectetur accusamus est rerum quisquam at. Perferendis amet ea praesentium ut distinctio iure asperiores. Enim qui nesciunt corporis labore. Quasi fugit commodi blanditiis optio repudiandae. Possimus mollitia dignissimos natus sequi. Ex voluptas voluptas quos maiores beatae ex qui. Veniam nihil odio corrupti dolorem. Magni sed ullam porro reiciendis est molestias. Consectetur eius omnis ut aperiam voluptatem unde. Unde ad iusto accusamus vel odit. Illum sit tempore et numquam perferendis.', 19.00, NULL, 'SMD149', 'instock', 0, 112, '16.jpg', '16.jpg', 4, 1, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(12, 'Voluptatum Quod', 'voluptatum-quod', 'Reprehenderit et minima praesentium ullam dicta laborum. Aut accusantium minima molestiae. Qui non illo et nisi. Autem libero aut sint consectetur cum illum.', 'Dolores tempora soluta illum et repudiandae. Fugit autem dignissimos quidem animi impedit necessitatibus aut. Qui voluptas eos numquam vel est similique blanditiis recusandae. Suscipit vero ea facilis nihil amet a. Nam unde sit corporis laboriosam illo dicta. Iste beatae ut earum suscipit at vel. Deserunt et illo ut qui dolor optio rerum. Perspiciatis est exercitationem officiis quaerat quaerat est neque libero. Non quaerat qui minus ut modi et rerum beatae.', 20.00, NULL, 'SMD104', 'instock', 0, 106, '16.jpg', '16.jpg', 2, 3, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(13, 'Aut Est', 'aut-est', 'Quod enim quo voluptas et et est et. Totam similique et voluptatem id eaque esse. Quaerat voluptatem consectetur corporis earum quis.', 'Explicabo veritatis molestiae quam ut modi tempora. Asperiores nulla omnis est quae consectetur. Blanditiis dolor aperiam dignissimos nisi incidunt. Vel ratione dignissimos cupiditate autem sit. Delectus aperiam fugit reiciendis velit eligendi nostrum. Voluptas molestias quas quo provident et animi. Tempora veniam ullam ut voluptatibus unde quia minus. Aspernatur aspernatur quidem atque.', 19.00, NULL, 'SMD288', 'instock', 0, 188, '11.jpg', '11.jpg', 4, 4, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(14, 'Id Sequi', 'id-sequi', 'Perferendis qui debitis voluptatem nostrum. Sint quae hic quo ratione itaque consectetur. Voluptates consequuntur molestiae accusantium quod eligendi neque.', 'Dolor reiciendis magni ipsum sit reiciendis optio debitis. Repellat esse tenetur dignissimos nostrum repellat. Quas optio corrupti quae ex repellat optio ut. Id labore fugiat delectus doloribus ut consequatur. Fugit voluptas ipsam nulla tenetur. Quidem fuga sint natus numquam distinctio neque ullam accusantium. Veniam optio id fuga quas. Sed error similique excepturi explicabo enim quo assumenda aut. Omnis autem dignissimos sequi enim amet.', 20.00, NULL, 'SMD138', 'instock', 0, 122, '10.jpg', '10.jpg', 4, 4, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(15, 'Ut Provident', 'ut-provident', 'Voluptatum ea eveniet exercitationem animi nihil consequuntur fugiat. Animi ut aut optio optio ab quia et. Voluptatem occaecati aut quo exercitationem. Sed eligendi dicta eveniet sapiente.', 'Incidunt aut veniam id fugiat officia inventore molestiae. Ut sunt corrupti aliquam soluta inventore perferendis eius. Corrupti voluptatem dolore non numquam voluptas omnis. Odit est aut unde minus impedit. Possimus eos dicta omnis in optio nulla. Corporis provident facere voluptatum sint. Dicta porro quam esse qui odio dicta aperiam. Eius illo ex pariatur consectetur est autem vitae. Asperiores neque et omnis odit et blanditiis voluptatibus ut. Dolores ipsum voluptatem non molestiae.', 21.00, NULL, 'SMD161', 'instock', 0, 106, '16.jpg', '16.jpg', 3, 5, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(16, 'Est Sint', 'est-sint', 'Perferendis et a deserunt quia nulla nisi eum. Expedita rem consectetur maxime laudantium itaque fugiat sit. Aperiam neque ut atque.', 'Vel natus aperiam ut error laudantium officia unde nostrum. Id nam quisquam voluptatem cumque ipsam expedita aut. Vel dolorem reprehenderit esse. Et id occaecati voluptatem eum quo id. Vero omnis odio unde optio. Aut eius ut aut sit quia. Enim aut molestiae consequuntur. Fugiat distinctio molestiae ut ipsam nisi vel. Voluptas modi in cupiditate velit rerum. At sint minima et voluptatem. Sint tenetur aliquid qui optio. Temporibus quas dolore voluptates ut. Et aliquid excepturi nulla autem.', 22.00, NULL, 'SMD110', 'instock', 0, 133, '21.jpg', '21.jpg', 2, 1, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(17, 'Deserunt Voluptas', 'deserunt-voluptas', 'Repudiandae rerum blanditiis dolorem fugiat eaque fugit id. Aut ipsa fugiat minima enim veniam ratione rerum. Est et ut aut aut et dolores culpa.', 'Et quaerat voluptas alias dignissimos. Ratione facilis qui voluptatem est qui eos qui nam. Accusantium nisi fuga consequatur quia est accusamus. Ut laudantium autem soluta quia dolorem cum. Dolores occaecati ipsa laborum maiores repellendus optio. Doloremque quasi ullam itaque eveniet sint praesentium eum. Quasi in ut sit temporibus iste fuga voluptas. Amet animi veritatis corporis et quod.', 20.00, NULL, 'SMD374', 'instock', 0, 186, '17.jpg', '17.jpg', 3, 2, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(18, 'Quisquam Dolor', 'quisquam-dolor', 'Ab illum aperiam a. Et dolore natus laboriosam quo ut sit sapiente.', 'Quidem id suscipit magnam rerum et iure. Eaque deleniti a et voluptatem et in similique. Aut consequatur enim autem. A et earum delectus cupiditate. Quia est numquam blanditiis. Qui ut voluptas minus enim eaque. Qui ut consectetur iste debitis architecto cumque autem maiores. Dolorum omnis excepturi qui quidem nulla ad architecto. Veritatis ullam consectetur quia esse voluptatum alias.', 19.00, NULL, 'SMD375', 'instock', 0, 200, '3.jpg', '3.jpg', 5, 2, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(19, 'Est Molestiae', 'est-molestiae', 'Magnam voluptas similique iure voluptatum aut. Consequatur cum tenetur molestiae veniam. Ipsa porro harum praesentium quod vero quis nihil.', 'Nisi iure sit sunt quo aliquid qui deleniti. Ipsam est temporibus nisi quos. Adipisci sint consectetur qui ut. At dolore maxime sit non in. Unde ut velit modi sint. Temporibus quo libero ipsum sit quis. Voluptatem esse vero id qui soluta est veritatis sit. Qui sequi est earum explicabo sint. Aut et placeat aut et. Unde velit voluptatem odit magnam voluptatem aut.', 20.00, NULL, 'SMD223', 'instock', 0, 172, '5.jpg', '5.jpg', 2, 5, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(20, 'Ea Adipisci', 'ea-adipisci', 'Unde aut sit soluta quidem laudantium et. Placeat aut quis aut a expedita. Sequi voluptatum numquam nihil assumenda adipisci sit in. Consequatur expedita minima excepturi deserunt aut sunt.', 'Minus eos repudiandae eligendi rerum aliquam reprehenderit totam. Ipsum tempore et dolor consectetur debitis consequatur tempore. Eaque vitae perspiciatis et dolor ut commodi pariatur. Consequatur iste illo aliquid aut. Animi dolores perferendis aut qui maxime eveniet labore. Exercitationem exercitationem alias delectus. Sunt incidunt nobis ut laudantium quo. Quaerat ut natus asperiores. Sit consequatur dolorem saepe recusandae ipsam. Est commodi error culpa.', 16.00, NULL, 'SMD187', 'instock', 0, 161, '7.jpg', '7.jpg', 6, 6, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(21, 'Eos Voluptatem', 'eos-voluptatem', 'Odio iste ut dolor nam. Et autem dolor illo. Tenetur similique repudiandae inventore voluptate dolores nisi. Rem saepe eum eos eaque.', 'Non enim vel sit. Iure et optio facere et quos ab fugiat voluptas. Culpa magni et omnis voluptas. Voluptatem laboriosam quia praesentium enim voluptatem. Voluptas optio corrupti ab id. Fugit et magnam non ab sed voluptatem quo. Dolor saepe et ad necessitatibus. Ipsa non perferendis nihil et illum provident. Dolore et et dicta quidem. Ad autem beatae ratione. Qui consequatur eaque vitae fuga. Reprehenderit voluptatum dolor cupiditate non sunt. Molestiae consequatur fugit iusto et natus facilis.', 12.00, NULL, 'SMD205', 'instock', 0, 176, '14.jpg', '14.jpg', 3, 3, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(22, 'Enim Id', 'enim-id', 'Qui quod nesciunt mollitia iste adipisci vel sed incidunt. Illo aut tempora esse. Qui nesciunt aperiam impedit enim.', 'Ullam qui optio ducimus ducimus at necessitatibus. Enim aspernatur ut officiis ut qui nobis. Laboriosam dicta est id nemo aut aspernatur voluptatem. Et est earum ratione autem. Consequuntur sunt officia modi est at. Numquam perspiciatis deleniti consequatur voluptas suscipit. Non cumque vero nemo accusamus nulla sunt ea. Expedita itaque commodi deserunt ex accusantium. A et ut soluta maxime praesentium. Ducimus quas et iste sit perspiciatis. Et ut velit et. Quae qui facere eaque natus.', 6.00, NULL, 'SMD419', 'instock', 0, 145, '19.jpg', '19.jpg', 5, 2, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(23, 'Maxime Ex', 'maxime-ex', 'Veniam amet maxime aliquam et praesentium voluptatem. Perspiciatis est dolore omnis consequatur ut consequatur libero. Nesciunt blanditiis harum tempora at tenetur.', 'Labore quis nemo omnis vero. Laborum est sapiente rerum soluta deserunt est beatae. Ex fugiat accusantium vitae tempora. Et totam magni inventore enim ducimus. Sint non mollitia voluptas. Officiis optio ut natus dignissimos et. Culpa quae culpa placeat. Deleniti molestias dolorem qui expedita. Quaerat dolores quia ea qui. Atque et vero sed aspernatur non aliquam similique. Sint deleniti eligendi tempora error dolores. Tempore quibusdam veritatis et debitis voluptatem laborum.', 22.00, NULL, 'SMD186', 'instock', 0, 144, '19.jpg', '19.jpg', 5, 6, '2024-02-06 02:14:57', '2024-02-06 02:14:57'),
(24, 'Illum Cum', 'illum-cum', 'Provident dolor quia eum earum. Nesciunt repellat consequuntur odio qui. Nisi iste quidem est aliquid magni. Minus et ab nam eos qui qui eum aliquam.', 'Eos et reprehenderit totam. Incidunt corporis dolorum est sed qui. Eum consectetur sit qui ratione amet quisquam. Et et et exercitationem rerum et quasi recusandae. Qui porro ut autem sit qui. Et voluptatibus suscipit aut. Repellat cum ea est cupiditate blanditiis omnis voluptas. Vitae et et cumque porro et dolorem. Iste beatae rerum exercitationem cum laboriosam doloribus magnam.', 7.00, NULL, 'SMD200', 'instock', 0, 157, '12.jpg', '12.jpg', 1, 6, '2024-02-06 02:14:57', '2024-02-06 02:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `shippings`
--

CREATE TABLE `shippings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `locality` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `zip` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'home',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `mode` enum('cod','card','paypal') NOT NULL,
  `status` enum('pending','approved','declined','refunded') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `utype` varchar(255) NOT NULL DEFAULT 'USR',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `utype`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Tineth', 'tineth@gmail.com', NULL, '$2y$12$J3TUl7KIc7MSWJSU.qQPBu414oXFUy7ynxtQBiJVxf/hod2.Libpu', 'USR', NULL, '2024-02-07 21:33:00', '2024-02-07 21:33:00'),
(2, 'Admin', 'admin@gmail.com', NULL, '$2y$12$vHUOEOmZlhvyzUm5n7b8W.B4YhSeOI2mHSTWE63gX3EnXcuq1gSnG', 'ADM', NULL, '2024-02-07 21:34:24', '2024-02-07 21:34:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `brands_name_unique` (`name`),
  ADD UNIQUE KEY `brands_slug_unique` (`slug`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`);

--
-- Indexes for table `shippings`
--
ALTER TABLE `shippings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shippings_order_id_foreign` (`order_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactions_user_id_foreign` (`user_id`),
  ADD KEY `transactions_order_id_foreign` (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `shippings`
--
ALTER TABLE `shippings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shippings`
--
ALTER TABLE `shippings`
  ADD CONSTRAINT `shippings_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
