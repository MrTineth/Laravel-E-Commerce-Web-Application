<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AppController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\WishlistController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Main Route
Route::get('/',[AppController::class,'index'])->name('app.index');

// About Route
Route::get('/about', function () { return view('about'); });

// Conatct Route
Route::get('/contact', function () { return view('contact'); });

// Shop Route
Route::get('/shop',[ShopController::class,'index'])->name('shop.index');

// Product Details Route
Route::get('/product/{slug}',[ShopController::class,'productDetails'])->name('shop.product.details');

// Cart Route
Route::get('/cart',[CartController::class,'index'])->name('cart.index');

// Add to Cart Route
Route::post('/cart/store', [CartController::class, 'addToCart'])->name('cart.store');

// Update Cart Route
Route::put('/cart/update', [CartController::class, 'updateCart'])->name('cart.update');

// Delete Cart Route
Route::delete('/cart/remove', [CartController::class, 'removeItem'])->name('cart.remove');

// Clear Cart Route
Route::delete('/cart/clear', [CartController::class, 'clearCart'])->name('cart.clear');

// Wishlist Route
Route::post('/wishlist/add',[WishlistController::class,'addProductToWishlist'])->name('wishlist.store');

// Count & Add Wishlist Route
Route::get('/cart-wishlist-count',[ShopController::class,'getCartAndWishlistCount'])->name('shop.cart.wishlist.count');

// Wishlist Review Route
Route::get('/wishlist',[WishlistController::class,'getWishlistedProducts'])->name('wishlist.list');

// Delete Wishlist Product Route
Route::delete('/wishlist/remove',[WishlistController::class,'removeProductFromWishlist'])->name('wishlist.remove');

// Clear All Product Wishlist Route
Route::delete('/wishlist/clear',[WishlistController::class,'clearWishlist'])->name('wishlist.clear');

// Move Product to Cart From Wishlist Route
Route::post('/wishlist/move-to-cart',[WishlistController::class,'moveToCart'])->name('wishlist.move.to.cart');

Auth::routes();

// User Route
Route::middleware('auth')->group(function(){
    Route::get('/my-account' ,[UserController::class, 'index'])->name('user.index');
});

// Admin Route
Route::middleware(['auth','auth.admin'])->group(function(){
    Route::get('/admin', [AdminController::class, 'index'])->name('admin.index');
});
