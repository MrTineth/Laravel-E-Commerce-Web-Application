<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Gloudemans\Shoppingcart\Facades\Cart;

class WishlistController extends Controller
{
    // Get Wishlist List

    public function getWishlistedProducts()
    {
    $items = Cart::instance("wishlist")->content();
    return view('wishlist',['items'=>$items]);
    }


    // Add Product to Wishlist

    public function addProductToWishlist(Request $request)
    {
    Cart::instance("wishlist")->add($request->id,$request->name,1,$request->price)->associate('App\Models\Product');
    return response()->json(['status'=>200,'message'=>'Success ! Item successfully added to your wishlist!']);

    }

    // Remove Product From Wishlish

    public function removeProductFromWishlist(Request $request)
    {
    $rowId = $request->rowId;
    Cart::instance("wishlist")->remove($rowId);
    return redirect()->route('wishlist.list');
    }

    // Clear Wishlist All Product

    public function clearWishlist()
    {
    Cart::instance("wishlist")->destroy();
    return redirect()->route('wishlist.list');
    }

    // Move Product to Cart From Wishlist

    public function moveToCart(Request $request)
    {
    $item = Cart::instance('wishlist')->get($request->rowId);
    Cart::instance('wishlist')->remove($request->rowId);
    Cart::instance('cart')->add($item->model->id, $item->model->name, 1, $item->model->regular_price)->associate('App\Models\Product');
    return redirect()->route('wishlist.list');
    }


}
